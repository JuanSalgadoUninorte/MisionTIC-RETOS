function enviar() { 
    document.getElementById("IdUsuario").action = "/comentario/enviar"; 
}
function ver() { 
    document.getElementById("IdUsuario").action = "/comentario/ver"; 
}
function eliminar() { 
    document.getElementById("IdUsuario").action = "/comentario/eliminar"; 
}
function modificar() { 
    document.getElementById("IdUsuario").action = "/comentario/modificar"; 
}